# Outpost Artemis: Deep Space Survival Simulator 🚀

An interactive lunar and Martian outpost resource-management simulator designed for kids ages 7–12, grounded in authentic **NASA Open Science data** (DONKI space weather alerts, OSDR biological microgravity research, and light-speed radio communication delays).

## ⚡ Hosting on Vercel (1-Click or CLI)

### Method 1: Drag & Drop Deploy (Fastest, zero code)
1. Unzip `outpost-artemis.zip`.
2. Go to [vercel.com/new](https://vercel.com/new).
3. Drag the unzipped folder directly into Vercel's deployment dropzone or import via GitHub.
4. Hit **Deploy** — your live simulation URL will be ready immediately!

### Method 2: Vercel CLI
```bash
npm i -g vercel
vercel
```

## 🛰️ NASA Science & Data Citing
- **NASA DONKI (Database of Notifications, Knowledge, Information):** Drives the solar flare (M-class / X-class) radiation spikes.
- **NASA OSDR (Open Science Data Repository):** Informs crew vigor, bone density decline, and hydroponic microgreens cycle.
- **NASA LRO & Artemis Shackleton Rim Data:** Simulates real lunar South Pole thermal environments (-130°C shadow traps and peaks of eternal light).
